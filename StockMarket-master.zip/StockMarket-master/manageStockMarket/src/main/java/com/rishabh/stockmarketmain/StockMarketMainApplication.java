package com.rishabh.stockmarketmain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMarketMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMarketMainApplication.class, args);
	}

}
