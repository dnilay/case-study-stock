export class User {
    username: string;
    password: string;
    mobile: string;
    email: string;
}
