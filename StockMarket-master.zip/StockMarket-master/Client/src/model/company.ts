export class Company {
    id: string;
    companyName: string;
    turnover: string;
    ceo: string;
    stockExchange: string;
    boardDirector: string;
    sector: string;
    writeup: string;
    companyCode: string;
}
