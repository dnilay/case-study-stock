export class CompareResult {
    compareItem1: string[];
    compareItem2: string[];
}
