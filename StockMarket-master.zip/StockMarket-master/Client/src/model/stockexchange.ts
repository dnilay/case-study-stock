export class Stockexchange {
    stockExchange: string;
    brief: string;
    address: string;
    remarks: string;
}
