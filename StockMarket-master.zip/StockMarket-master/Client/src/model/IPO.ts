export class IPO {
    companyName: string;
    stockExchange: string;
    price: string;
    totalNumber: string;
    openDate: string;
    remarks: string;
}
