export class FileUploadResult {
    companyName: string;
    stockExchange: string;
    recordNumber: string;
    fromDate: string;
    toDate: string;
}
