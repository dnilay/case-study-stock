package com.rishabh.CompanyData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
