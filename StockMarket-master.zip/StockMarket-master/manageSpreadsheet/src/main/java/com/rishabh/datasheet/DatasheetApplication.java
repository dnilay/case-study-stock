package com.rishabh.datasheet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatasheetApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatasheetApplication.class, args);
	}

}
